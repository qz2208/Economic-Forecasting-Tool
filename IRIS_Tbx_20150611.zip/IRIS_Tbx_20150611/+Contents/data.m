% data  Time Series and Database Management.
%
% * [Dates and Date Ranges](dates/Contents)
%
% * [Time Series (tseries Objects)](tseries/Contents)
%
% * [Time-Recursive Expressions (trec Objects)](trec/Contents)
%
% * [Basic Database Management](dbase/Contents)
%

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.
