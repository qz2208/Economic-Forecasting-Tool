function C = speclatexcode(This,~)
% speclatexcode  [Not a public function] \LaTeX\ code for texcommandobj objects.
%
% Backend IRIS function.
% No help provided.

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.

%--------------------------------------------------------------------------

C = This.caption;

end