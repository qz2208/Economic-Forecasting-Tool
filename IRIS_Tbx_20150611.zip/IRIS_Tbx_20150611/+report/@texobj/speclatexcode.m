function C = speclatexcode(This)
% speclatexcode  [Not a public function] Produce LaTeX code for tex objects.
%
% Backend IRIS function.
% No help provided.

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.

%--------------------------------------------------------------------------

C = speclatexcode@report.userinputobj(This);

end