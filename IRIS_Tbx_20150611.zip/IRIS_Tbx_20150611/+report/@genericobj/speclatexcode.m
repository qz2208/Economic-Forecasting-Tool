function C = speclatexcode(~,~)
% speclatexcode  [Not a public function] \LaTeX\ code for generic object.
%
% Backend IRIS function.
% No help provided.

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.

%--------------------------------------------------------------------------

C = '';

end