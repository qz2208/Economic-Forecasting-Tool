function C = speclatexcode(~,~)
% speclatexcode  [Not a public function] Produce LaTeX code for pagebreak objects.
%
% Backend IRIS function.
% No help provided.

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.

%--------------------------------------------------------------------------

C = '\clearpage';

end
