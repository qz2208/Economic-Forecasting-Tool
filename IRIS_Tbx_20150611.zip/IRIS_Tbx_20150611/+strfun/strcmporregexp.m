function Inx = strcmporregexp(List,Str)
% strcmporregexp  [Not a public function] Match string by plain comparison or by regexp engine.
%
% Backend IRIS function.
% No help provided.

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.

%--------------------------------------------------------------------------

isRexp = isrexp(Str) || ~all(isstrprop(Str,'alphanum') | Str=='_');

if isRexp
    start = regexp(List,Str,'once');
    Inx = ~cellfun(@isempty,start);
    if ischar(Str)
        % ##### Feb 2015 OBSOLETE and scheduled for removal.
        utils.warning('obsolete', ...
            ['The following string appears to be regexp; ', ...
            'wrapping it in rexp(...) function will be required ', ...
            'in future versions of IRIS: ''%s''.'], ...
            Str);
    end
else
    Inx = strcmp(List,Str);
end

end
