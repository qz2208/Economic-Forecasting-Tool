classdef tseriesPrimary < irisinp.tseries
    methods
        function This = tseriesPrimary(varargin)
            This.ReportName = 'Primary Time Series';
        end
    end
end
