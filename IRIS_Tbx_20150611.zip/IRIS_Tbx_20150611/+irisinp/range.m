classdef range < irisinp.generic
    properties
        ReportName = 'Date Range';
        Value = NaN;
        Omitted = @error;
        ValidFn = @(X) isdatrange(X);
    end
    

    methods
        function This = preprocess(This,~)
            if ischar(This.Value)
                This.Value = textinp2dat(This.Value);
            end
            if isequal(This.Value,Inf) || isequal(This.Value,@all)
                This.Value = Inf;
            elseif ~isinf(This.Value(1)) && ~isinf(This.Value(end))
                This.Value = This.Value(1) : This.Value(end);
            end
        end
    end
end
