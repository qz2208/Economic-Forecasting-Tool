classdef count < irisinp.generic
    methods
        function This = count(ReportName,varargin)
            This = This@irisinp.generic(varargin{:});
            This.ReportName = ReportName;
        end
    end
    
    
    properties
        ReportName = '';
        Value = NaN;
        Omitted = @error;
        ValidFn = @(x) isintscalar(x) && x >= 0;
    end
end
