classdef dbaseOptional < irisinp.dbase   
    methods
        function This = dbaseOptional(varargin)
            This = This@irisinp.dbase(varargin{:});
            This.ReportName = ['Optional ',This.ReportName];
            This.Omitted = [ ];
            validFn = This.ValidFn;
            This.ValidFn = @(X) validFn(X) || isequal(X,[ ]);
        end
    end
end
