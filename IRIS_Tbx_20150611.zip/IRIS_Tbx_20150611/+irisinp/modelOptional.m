classdef modelOptional < irisinp.model
    methods
        function This = modelOptional(varargin)
            This = This@irisinp.model(varargin{:});
            This.ReportName = ['Optional ',This.ReportName];
            This.Omitted = [ ];
            validFn = This.ValidFn;
            This.ValidFn = @(X) validFn(X) || isequal(X,[ ]);
        end
    end
end
