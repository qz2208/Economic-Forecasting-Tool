classdef tdataOptional < irisinp.tdata
    methods
        function This = tdataOptional(varargin)
            This = This@irisinp.tdata(varargin{:});
            This.Omitted = NaN;
        end
    end
end
