classdef generic < handle
    % irisinp.generic  [Not a public class] Base class for input argument objects.
    %
    % Backend IRIS class.
    % No help provided.
    
    % -IRIS Toolbox.
    % -Copyright (c) 2007-2015 IRIS Solutions Team.
    
    properties (Abstract)
        ReportName
        Value
        Omitted
        ValidFn
    end
    
    
    methods
        function IsValid = validate(This,X,State)
            IsValid = false;
            switch nargin(This.ValidFn)
                case 1
                    try
                        IsValid = This.ValidFn(X);
                    catch
                        IsValid = false;
                    end
                case 2
                    try
                        IsValid = This.ValidFn(X,State);
                    catch
                        IsValid = false;
                    end
            end
        end
        
        
        function assign(This,X)
            if ~isequal(X,@NA)
                This.Value = X;
            else
                if isequal(This.Omitted,@error)
                    utils.error('inp:generic:assign', ...
                        ['Expecting input argument ''%s'' but none found ', ...
                        'or its value fails validation.'], ...
                        This.ReportName);
                else
                    This.Value = This.Omitted;
                end
            end
        end
        
        
        function preprocess(This,varargin) %#ok<INUSD>
        end
    end
end
