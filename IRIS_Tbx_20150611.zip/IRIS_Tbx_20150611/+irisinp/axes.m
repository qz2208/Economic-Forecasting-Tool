classdef axes < irisinp.generic
    properties
        ReportName = 'Axes Handle';  
        Value = NaN;
        Omitted = @gca;
        ValidFn = @(X) length(X)==1 ...
            && ishghandle(X) && strcmp(get(X,'type'),'axes');
    end
end
