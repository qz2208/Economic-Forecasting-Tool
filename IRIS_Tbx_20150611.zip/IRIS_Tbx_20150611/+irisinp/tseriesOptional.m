classdef tseriesOptional < irisinp.tseries
    methods
        function This = tseriesOptional(varargin)
            This.ReportName = 'Optional Time Series';
            This.Omitted = [ ];
        end
    end
end
