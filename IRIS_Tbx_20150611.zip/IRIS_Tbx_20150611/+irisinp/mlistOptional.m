classdef mlistOptional < irisinp.mlist
    methods
        function This = mlistOptional(varargin)
            This = This@irisinp.mlist(varargin{:});
            This.ReportName = ['Optional ',This.ReportName];
            This.Omitted = @all;
        end
    end
end
