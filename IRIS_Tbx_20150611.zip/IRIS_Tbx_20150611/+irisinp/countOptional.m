classdef countOptional < irisinp.count
    methods
        function This = countOptional(Default,varargin)
            This = This@irisinp.count(varargin{:});
            This.Omitted = Default;
        end
    end
end
