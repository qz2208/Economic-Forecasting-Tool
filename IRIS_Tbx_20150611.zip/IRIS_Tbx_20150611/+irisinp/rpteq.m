classdef rpteq < irisinp.generic
    properties
        ReportName = 'Report Equations';
        Value = NaN;
        Omitted = @error;
        ValidFn = @(X) isa(X,'rpteq');
    end
end
