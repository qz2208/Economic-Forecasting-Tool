function varargout = parse(This,varargin)

nInp = length(This.Inp);

state = struct();
state.Func = This;
state.NUser = length(varargin);
state.IUser = 0;

iUser = 1;
for i = 1 : nInp
    state.IUser = iUser; 
    state.NUserLeft = length(varargin);
    
    isValid = false;
    if ~isempty(varargin)
        x = varargin{1};
        state.IsOptAfter = ...
            ~iseven(length(varargin)) && iscellstr(varargin(2:2:end));
        isValid = validate(This.Inp{i},x,state);
        if isValid
            varargin(1) = [ ];
            iUser = iUser + 1;
        end
    end

    if ~isValid
        x = @NA;
    end
    
    assign(This.Inp{i},x);
end

for i = 1 : nInp
    preprocess(This.Inp{i},This);
end

% Return validated input arguments.
varargout = cell(1,nInp+1);
for i = 1 : nInp
    varargout{i} = This.Inp{i}.Value;
end

% Return remaining options in one cell array.
varargout{end} = varargin;

end
