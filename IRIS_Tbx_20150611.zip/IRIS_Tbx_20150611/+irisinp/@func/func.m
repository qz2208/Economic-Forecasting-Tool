classdef func < handle
    % irisinp.func  [Not a public class] Define and store input arguments 
    % for one function.
    %
    % Backend IRIS class.
    % No help provided.
    
    % -IRIS Toolbox.
    % -Copyright (c) 2007-2015 IRIS Solutions Team.
    
    properties
        Inp = cell(1,0);
        InpClassName = cell(1,0);
    end
    
    
    methods
        varargout = parse(varargin)
        
        
        function This = func(varargin)
            if isempty(varargin)
                return
            end
            if nargin==1 && isa(varargin{1},'irisinp.func')
                This = varargin{1};
                return
            end
            for i = 1 : nargin
                inp = varargin{i};
                This.Inp{i} = inp;
                className = regexp(class(inp),'\.','split');
                This.InpClassName{i} = className{2};
            end
        end
    end
end
