classdef model < irisinp.generic
    properties
        ReportName = 'Model';
        Value = NaN;
        Omitted = @error;
        ValidFn = @(X) ismodel(X);
    end
    
    
    methods
        function This = model(MaxNAlt)
            % irisinp.model() - model with any number of parameterizations.
            % irisinp.model(1) - model with single parameterization.
            if nargin==0
                MaxNAlt = Inf;
            end
            if MaxNAlt==1
                This.ReportName = [ ...
                    This.ReportName, ...
                    ' with Single Parameterization', ...
                    ];
            end
            validFn = This.ValidFn;
            This.ValidFn = @(X) validFn(X) && length(X)<=MaxNAlt;
        end
    end
end
