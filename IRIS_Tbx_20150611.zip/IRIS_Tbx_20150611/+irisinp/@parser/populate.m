function X = populate()
% populate  [Not a public function] Define input arguments for IRIS
% functions and store them in irisinp.parser.Container.
%
% Backend IRIS function.
% No help provided.

% -IRIS Toolbox.
% -Copyright (c) 2007-2014 IRIS Solutions Team.

%--------------------------------------------------------------------------

X = struct();


% Dbase folder
%--------------
X.dbase = struct();

X.dbase.dbfun = irisinp.func( ...
    irisinp.funch, irisinp.dbase );

X.dbase.dbminuscontrol = irisinp.func( ...
    irisinp.model, irisinp.dbase, irisinp.dbaseOptional );

X.dbase.dbnames = irisinp.func( ...
    irisinp.dbase );

X.dbase.dbrange = irisinp.func( ...
    irisinp.dbase, irisinp.mlistOptional );


% Irisoptim package
% ------------------
X.irisoptim = struct() ;

X.irisoptim.alps = irisinp.func( ...
    irisinp.funch, irisinp.numeric, irisinp.numeric, irisinp.numeric) ;


% Model class
%-------------
X.model = struct();

X.model.simulate = irisinp.func( ...
    irisinp.modelSolved, irisinp.dbase, irisinp.rangeProper );

X.model.estimate = irisinp.func( ...
    irisinp.modelSolved(1), irisinp.dbase, irisinp.rangeProper, ...
    irisinp.estim, irisinp.systempriorsOptional );

X.model.filter = irisinp.func( ...
    irisinp.modelSolved, irisinp.dbase, irisinp.rangeProper, ...
    irisinp.dbaseOptional );

X.model.resample = irisinp.func( ...
    irisinp.modelSolved(1), irisinp.dbaseOptional, irisinp.rangeProper, ...
    irisinp.count('Number of Draws'), irisinp.dbaseOptional );

X.model.shockdb = irisinp.func( ...
    irisinp.model, irisinp.dbaseOptional, irisinp.rangeProper, ...
    irisinp.countOptional(1,'Number of Draws') );


% Plan class
%------------
X.plan = struct();

X.plan.plan = irisinp.func( ...
    irisinp.modelOptional, irisinp.rangeProper, ...
    irisinp.listOptional, irisinp.listOptional, irisinp.listOptional );


% Rpteq class
%-------------
X.rpteq = struct();

X.rpteq.run = irisinp.func( ...
    irisinp.rpteq(), irisinp.dbase, irisinp.dates );


% Tseries class
%---------------
X.tseries = struct();

X.tseries.acf = irisinp.func( ...
    irisinp.tseriesPrimary, irisinp.datesTseries('min') );

X.tseries.arma = irisinp.func( ...
    irisinp.tseries, irisinp.tseries, ...
    irisinp.numeric, irisinp.numeric, ...
    irisinp.rangeProper );

X.tseries.band = irisinp.func( ...
    irisinp.axes, irisinp.rangeTseries('max'), ...
    irisinp.tseries, irisinp.tseries, irisinp.tseries, irisinp.plotspec );

X.tseries.bwf = irisinp.func( ...
    irisinp.tseriesPrimary, irisinp.count('Order'), ...
    irisinp.rangeTseries('max') );

X.tseries.errorbar = irisinp.func( ...
    irisinp.axes, irisinp.rangeTseries('max'), ...
    irisinp.tseries, irisinp.tseries, irisinp.tseriesOptional, ...
    irisinp.plotspec );

X.tseries.filter = irisinp.func( ...
    irisinp.tseriesPrimary, irisinp.rangeTseries('max') );

X.tseries.plot = irisinp.func( ...
    irisinp.axes, irisinp.rangeTseries('max'), ...
    irisinp.tseries, irisinp.plotspec );

X.tseries.tseries = irisinp.func( ...
    irisinp.dates, irisinp.tdataOptional, irisinp.commentOptional );

end
