classdef parser < handle
    % irisinp.parser  [Not a public class] Call appropriate irisinp.func 
    % and parse user inputs.
    %
    % Backend IRIS class.
    % No help provided.
    
    % -IRIS Toolbox.
    % -Copyright (c) 2007-2015 IRIS Solutions Team.
    
    properties (Constant)
        Container = irisinp.parser.populate();
    end
    
    
    methods (Static)
        varargout = populate(varargin)
        
        
        function varargout = parse(Ref,varargin)
            split = regexp(Ref,'\.','split');
            category = split{1};
            funcName = split{2};
            funcObj = irisinp.parser.Container.(category).(funcName);
            [varargout{1:nargout}] = parse(funcObj,varargin{:});
        end
    end
end
