classdef mlist < irisinp.generic   
    properties
        ReportName = 'List';
        Value = NaN;
        Omitted = @all;
        ValidFn = @(X,State) iscellstr(X) || isrexp(X) ...
            || isequal(X,@all) || isequal(X,Inf) ...
            || ( ischar(X) && State.IsOptAfter );
    end
    
    
    methods
        function preprocess(This,varargin)
            preprocess@irisinp.generic(This,varargin);
            if isequal(This.Value,Inf)
                This.Value = @all;
            end
        end
    end
end
