classdef rangeProper < irisinp.range
    methods
        function This = rangeProper(varargin)
            This.ReportName = ['Proper ',This.ReportName];
            This.ValidFn = @(X) isdatrangeproper(X);
        end
    end
end
