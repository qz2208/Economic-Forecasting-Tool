classdef plotspec < irisinp.generic
    properties
        ReportName = 'Plot Specs';  
        Value = NaN;
        Omitted = { };
        ValidFn = @(X,State) ischar(X) && ~iseven(State.NUserLeft);
    end
    
    
    methods
        function This = preprocess(This,~)
            if isempty(This.Value)
                This.Value = { };
            elseif ischar(This.Value)
                This.Value = { This.Value };
            end
        end
    end 
end
