classdef commentOptional < irisinp.comment
    methods
        function This = commentOptional(varargin)
            This = This@irisinp.comment(varargin{:});
            This.Omitted = '';
            validFn = This.ValidFn;
            This.ValidFn = ...
                @(X,State) validFn(X) && ~iseven(State.NUserLeft);
        end
    end
end
