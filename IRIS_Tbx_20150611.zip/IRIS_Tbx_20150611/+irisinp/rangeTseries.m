classdef rangeTseries < irisinp.range
    properties
        SpecRangeFlag
    end
    

    methods
        function This = rangeTseries(SpecRangeFlag,varargin)
            This = This@irisinp.range(varargin{:});
            This.ReportName = 'Time Series Range';
            This.Omitted = Inf;
            This.SpecRangeFlag = SpecRangeFlag;
        end
        
        
        function This = preprocess(This,Func)
            This = preprocess@irisinp.range(This,Func);
            ixPrimary = strcmp(Func.InpClassName,'tseriesPrimary');
            if any(ixPrimary)
                x = Func.Inp{ixPrimary}.Value;
                flag = all(freqcmp(This.Value,x));
                if ~flag
                    utils.error('inp:rangeTseries:preprocess', ...
                        ['Input range frequency fails to match ', ...
                        'input time series frequency.']);
                end
                This.Value = ...
                    specrange(x,This.Value,This.SpecRangeFlag);
            end
        end
    end
end
