classdef estim < irisinp.generic
    properties
        ReportName = 'Estimation Struct';  
        Value = NaN;
        Omitted = @error;
        ValidFn = @(X,State) isstruct(X) && ~isempty(fieldnames(X)) ...
            && irisinp.estim.myvalidate(X,State)
    end
    
    
    methods (Static)
        function Flag = myvalidate(X,State)
            func = State.Func;
            ix = strcmp(func.InpClassName,'modelSolved');
            m = State.Func.Inp{ix}.Value;
            [validNames,invalidNames] = verifyestim(m,X);
            Flag = true;
            if ~isempty(invalidNames)
                utils.warning('inp:estim:myvalidate', ...
                    'This is not a valid name in estimation struct: ''%s''.', ...
                    invalidNames{:});
                Flag = false;
            end
            if isempty(validNames)
                utils.warning('inp:estim:myvalidate', ...
                    'No valid names found in estimation struct.');
                Flag = false;
            end
        end
    end
end
