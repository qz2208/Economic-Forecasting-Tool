classdef listOptional < irisinp.list
    methods
        function This = listOptional(varargin)
            This = This@irisinp.list(varargin{:});
            This.ReportName = ['Optional ',This.ReportName];
            This.Omitted = { };
        end
    end
end
