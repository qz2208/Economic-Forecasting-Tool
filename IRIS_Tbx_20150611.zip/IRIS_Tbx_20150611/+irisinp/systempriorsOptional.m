classdef systempriorsOptional < irisinp.systempriors
    methods
        function This = systempriorsOptional(varargin)
            This = This@irisinp.systempriors(varargin{:});
            This.ReportName = 'System Priors';
            This.Omitted = [ ];
            This.ValidFn = @(X) isempty(X) || isa(X,'systempriors');
        end
    end
end
