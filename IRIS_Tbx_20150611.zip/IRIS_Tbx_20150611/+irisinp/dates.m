classdef dates < irisinp.generic
    properties
        ReportName = 'Dates';
        Value = NaN;
        Omitted = @error;
        ValidFn = @(x) isdatinp(x); 
    end
    

    methods
        function This = preprocess(This,~)
            if ischar(This.Value)
                This.Value = textinp2dat(This.Value);
            end
        end
    end
end
