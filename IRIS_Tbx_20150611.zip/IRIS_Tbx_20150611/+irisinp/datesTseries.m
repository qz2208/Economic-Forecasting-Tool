classdef datesTseries < irisinp.dates
    properties
        SpecRangeFlag
    end
    
    
    methods
        function This = datesTseries(SpecRangeFlag,varargin)
            This = This@irisinp.dates(varargin{:});
            This.ReportName = 'Time Series Dates';
            This.Omitted = Inf;
            This.SpecRangeFlag = SpecRangeFlag;
        end
        
        
        function This = preprocess(This,Func)
            This = preprocess@irisinp.dates(This,Func);
            if isequal(This.Value,Inf) || isequal(This.Value,@all)
                ixPrimary = strcmp(Func.InpClassName,'tseriesPrimary');
                if any(ixPrimary)
                    x = Func.Inp{ixPrimary}.Value;                    
                    specDates = x.start + (0 : size(x.data,1)-1);
                    if strcmpi(This.SpecRangeFlag,'max')
                        ixObs = any(~isnan(x.data(:,:)),2);
                    elseif strcmpi(This.SpecRangeFlag,'min')
                        ixObs = all(~isnan(x.data(:,:)),2);
                    else
                        ixObs = false(size(specDates));
                    end
                    This.Value = specDates(ixObs);
                end
            end
        end
    end
end
