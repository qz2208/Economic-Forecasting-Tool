%% Publish Tutorial Files to PDFs
%
% The following commands can be used to create PDF versions of the tutorial
% files:

%{
    latex.publish('read_me_first.m',[],'evalCode=',false);