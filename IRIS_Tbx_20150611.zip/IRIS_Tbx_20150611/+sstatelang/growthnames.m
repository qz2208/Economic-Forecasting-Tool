% !growthnames  Pattern for creating growth names.
%
% Syntax
% =======
%
%     !growthname := string_pattern;
%     !growthname := [function_pattern];
%
% Description
% ============
%
% -Example