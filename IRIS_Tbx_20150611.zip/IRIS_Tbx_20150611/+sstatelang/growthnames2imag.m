% !growthnames2imag  Combine level and growth variables to complex numbers.
%
% Syntax
% =======
%
%     !equations
%         !growthnames2imag
%
% Description
% ============
%
% Example
% ========
%

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.
