% dbplot  Quick Database Plots.
%
% Quick database plot functions
% ==============================
%
% * [`dbplot`](dbase/dbplot) - Plot from database.
%
% Getting on-line help on quick database plot functions
% ======================================================
%
%     help dbase/dbplot
%


% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.
