function varargout = error(Id,Body,varargin)
% error  [Not a public function] IRIS error master file.
%
% Backend IRIS function.
% No help provided.

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.

%--------------------------------------------------------------------------

if ~isempty(Body) && Body(1) == '#'
    Body = utils.hashmessage(Body);
end

if true % ##### MOSW
    Body = strrep(Body,'Uncle','Matlab');
else
    Body = strrep(Body,'Uncle','Octave'); %#ok<UNRCH>
end

% Throw an error with stack of non-IRIS function calls.
stack = utils.getstack();
if isempty(stack)
    stack = struct('file','','name','command prompt.','line',NaN);
end

msg = sprintf('IRIS Toolbox Error @ %s.',(Id));
msg = [msg,mosw.sprintf(['\n*** ',Body],varargin{:})];
msg = regexprep(msg,'(?<!\.)\.\.(?!\.)','.');

if nargout == 0
    tmp = struct();
    tmp.message = msg;
    tmp.identifier = ['IRIS:',Id];
    tmp.stack = stack;
    error(tmp);
else
    varargout{1} = msg;
end

end
