function Stack = getstack()
% getstack  [Not a public function] Get the stack of callers with IRIS functions excluded.
%
% Backend IRIS function.
% No help provided.

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.

%--------------------------------------------------------------------------

Stack = dbstack('-completenames');

% Get the IRIS root directory name.
[ans,irisFolder] = fileparts(irisget('irisroot')); %#ok<NOANS,ASGLU>
irisFolder = lower(irisFolder);

i = length(Stack);
while i > 0 && isempty(strfind(lower(Stack(i).file),irisFolder))
    i = i - 1;
end
Stack = Stack(i+1:end);

end
