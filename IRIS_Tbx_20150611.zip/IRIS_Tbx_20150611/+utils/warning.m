function warning(Id,Body,varargin)
% warning  [Not a public function] IRIS warning master file.
%
% Backend IRIS function.
% No help provided.

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.

%--------------------------------------------------------------------------

try %#ok<TRYNC>
    q = warning('query',['IRIS:',Id]);
    if strcmp(q.state,'off')
        return
    end
end

if ~isempty(Body) && Body(1) == '#'
    Body = utils.hashmessage(Body);
end

if true % ##### MOSW
    Body = strrep(Body,'Uncle','Matlab');
else
    Body = strrep(Body,'Uncle','Octave'); %#ok<UNRCH>
end

stack = utils.getstack();

msg = mosw.sprintf('<a href="">IRIS Toolbox Warning</a> @ %s.',Id);
msg = [msg,mosw.sprintf(['\n*** ',Body],varargin{:})];
msg = regexprep(msg,'(?<!\.)\.\.(?!\.)','.');

msg = [msg,utils.displaystack(stack)];
state = warning('off','backtrace');
warning(['IRIS:',Id],'%s',msg);
warning(state);

strfun.loosespace();

end
