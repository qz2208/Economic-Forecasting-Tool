% <...>  Regular expression in log variable list.
%
% Syntax
% =======
%
%     !log_variables
%         <Regexp>, ...
%
% Description
% ============
%
% See help on [`!log_variables`](modellang/logvariables).

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.
