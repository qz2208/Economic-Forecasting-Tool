% !case  Part of the !switch structure.
%
% See help on [`!switch`](modellang/switch).
%

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.