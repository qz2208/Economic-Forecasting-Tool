% !end  Part of the !for, !if, and !switch structures.
%
% See help on [`!for`](modellang/for), [`!if`](modellang/if),
% [`!switch`](modellang/switch).
%

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.