% %  Line comments.
%
% Syntax
% =======
%
%     % Anything from the percent sign until the end of line is discarded.
%
% Description
% ============
%
% Example
% ========

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.
