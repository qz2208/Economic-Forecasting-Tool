% !do  Part of the !for structure.
%
% See help on [for](modellang/for).