% !else  Part of the !if structure.
%
% See help on [`!if`](modellang/if).
%

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.