function Opt = dtrends(Opt)
% dtrends  [Not a public function] Auto value for option dtrends=.
%
% Backend IRIS function.
% No help provided.

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.

%--------------------------------------------------------------------------

Opt.dtrends = ~Opt.deviation;

end
