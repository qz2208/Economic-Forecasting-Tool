function varargout = validfn()
% validfn  [Not a public function] Frequently used validators.
%
% Backend IRIS function.
% No help provided.

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.

persistent VALIDFN;

%--------------------------------------------------------------------------

if ~isempty(VALIDFN) && isstruct(VALIDFN)
    varargout{1} = VALIDFN;
    return
end

VALIDFN = struct();

VALIDFN.figureopt = @(x) ...
    isempty(x) || ( iscell(x) && iscellstr(x(1:2:end)) );

VALIDFN.chksstate = @(x) islogicalscalar(x) ...
    || (iscell(x) && iscellstr(x(1:2:end)));

VALIDFN.matrixfmt = @(x) ischar(x) && any(strcmpi(x,{'plain','numeric'}));

VALIDFN.solve = @(x) islogicalscalar(x) ...
    || (iscell(x) && iscellstr(x(1:2:end)));

VALIDFN.sstate = @(x) islogical(x) ...
    || (iscell(x) && iscellstr(x(1:2:end))) ...
    || isa(x,'function_handle') ...
    || (iscell(x) && ~isempty(x) && isa(x{1},'function_handle'));

VALIDFN.subplot = @(x) ...
    isequal(x,@auto) ...
    || ( isnumeric(x) ...
    && any(length(x)==[1,2]) && all(isround(x)) && all(x>0) );

varargout{1} = VALIDFN;

end
