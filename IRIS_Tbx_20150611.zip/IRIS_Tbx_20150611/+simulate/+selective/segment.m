function [V,Dcy,Exit] = segment(S,V0)
% segment  [Not a public function] Non-linear simulation of one segment.
%
% Backed IRIS function.
% No help provided.

% -IRIS Toolbox.
% -Copyright (c) 2007-2015 IRIS Solutions Team.

%--------------------------------------------------------------------------

Dcy = [ ];
Exit = 0;

ny = size(S.Z,1);
nxx = size(S.T,1);
nb = size(S.T,2);
nf = nxx - nb;
ne = size(S.Ea,1);
nEqtn = length(S.Eqtn);
eqtnNI = S.Selective.EqtnNI;
sgmStr = S.Selective.SegmentString;
ixNonl = S.Selective.IxNonlin;
nn = sum(ixNonl);
nPerNonl = S.Selective.NPerNonlin;
rangeNonl = 1 : nPerNonl; 
isAnch = ~isempty(S.Anch) && any(S.Anch(:));

% If `Jv` or `Je` is empty because there were too many data points to
% update, call recursive linear simulation instead.
isFastUpd = ~isempty(S.Selective.Jv) && ~isempty(S.Selective.Je);

% Prepare exogenized/endogenized update
%---------------------------------------
lastExg = 0;
if isAnch
    % `eaAnch`, `euAnch` do not include init cond.
    % `ixUpdN` does include init cond.
    Je = S.Selective.Je;
    yxxAnch = S.Anch(1:ny+nxx,:);
    eaAnch = S.Anch(ny+nxx+(1:ne),:);
    euAnch = S.Anch(ny+nxx+ne+(1:ne),:);
    lastExg = max([0,find(any(yxxAnch,1),1,'last')]);
    lastEndgA = max([0,find(any(eaAnch,1),1,'last')]);
    lastEndgU = max([0,find(any(euAnch,1),1,'last')]);
    eaAnch = eaAnch(:,1:lastEndgA);
    euAnch = euAnch(:,1:lastEndgU);
    ixUpdN = [ false(ny+nxx,1), repmat(S.Selective.IxUpdN,1,nPerNonl) ];
end

% Prepare nonlinear update
%--------------------------
nPerUpd = max(nPerNonl,lastExg);
[y,xx] = simulate.linear.plain(S, ...
    S.IsDeviation,S.Alp0,S.Ea,S.Eu,nPerUpd,[ ]);
% Add init condition.
yxx = [ [ nan(ny,1); nan(nf,1); S.U*S.Alp0 ] , [y; xx] ];
if S.IsDeviation && S.IsAddSstate
    yxx = yxx + [ S.YBar; S.XBar ];
    if isAnch
        % Add steady-state lines to tunes because all yxx results here do include
        % the steady-state lines, too. It is easier to add them here than subtract
        % them in doEvalDcy().
        S.Tune = S.Tune + [S.YBar(:,2:end);S.XBar(:,2:end)];
    end
end
e = S.Ea;
e(:,1) = e(:,1) + S.Eu;
e = [ zeros(ne,1), e ];

Jv = S.Selective.Jv( 1:nnz(S.Selective.IxUpd)*nPerUpd, : );
ixUpd = [ false(ny+nxx,1), repmat(S.Selective.IxUpd,1,nPerUpd) ];

% Delog only the variables that enter nonlinear equations.
ixLogUpdN = [S.IxYLog;S.IxXLog] & S.Selective.IxUpdN;
isLogUpdN = any(ixLogUpdN);

% Time vector for evaluating nonlinear equations; take into account
% pre-sample init condition.
tVec = 1 + rangeNonl;

% Current parameter values.
p = real(S.Assign(1,S.NameType==4));

% Absolute time within the entire nonlinear simulation for sstate
% references.
tVecAbs = -S.MinT + S.First + rangeNonl - 1;
L = S.L;

if isequal(S.Solver,@qad)
    % QaD algorithm
    %---------------
    [V,Dcy,Exit] = simulate.selective.qad(@doEvalDcy,V0,S.Selective);
else
    % Optimization Tbx
    %------------------
    if isequal(S.Solver,@fsolve)
        [V,Dcy,flag] = fsolve(@doEvalDcy,V0,S.OptimSet);
    elseif isequal(S.Solver,@lsqnonlin)
        [V,~,Dcy,flag] = lsqnonlin(@doEvalDcy,V0,[ ],[ ],S.OptimSet);
    end
    V = reshape(V,nn,nPerNonl);
    if flag>0
        Exit = 1;
    else
        Exit = -1;
    end
end

% Failed to converge
%--------------------
if Exit < 0
    doRptFailure();
end

return

    
    
    function Dcy = doEvalDcy(V)
        yxx1 = yxx;
        doUpdateNonl();
        e1 = e;
        if isAnch
            doExogenize();
        end
        
        % Delog variables that occur in nonlinear equations.
        if isLogUpdN
            yxx1(ixLogUpdN,:) = real(exp(yxx1(ixLogUpdN,:)));
        end
        
        % Evaluate discrepancies.
        y1 = yxx1(1:ny,:);
        xx1 = yxx1(ny+1:end,:);
        errMsg = { };
        Dcy = zeros(nEqtn,nPerNonl);
        ixNan = false(1,nEqtn);
        for j = find(ixNonl)
            try
                jDcy = eqtnNI{j}(y1,xx1,e1,p,tVec,L,tVecAbs);
                ixNan(j) = any(~isfinite(jDcy));
                Dcy(j,:) = jDcy;
            catch Err
                errMsg{end+1} = S.Eqtn{j}; %#ok<AGROW>
                errMsg{end+1} = Err.message; %#ok<AGROW>
            end
        end
        Dcy = Dcy(ixNonl,:);
        if any(ixNan) || ~isempty(errMsg)
            doErrors();
        end
        
        return

        
        
        function doUpdateNonl()
            if isFastUpd
                yxx1(ixUpd) = yxx1(ixUpd) + Jv*V(:);
            else
                % Incremental simulation of nonlinear addfactors.
                isDeviation = true;
                [addY,addXx] = simulate.linear.plain(S, ...
                    isDeviation,[ ],[ ],[ ],nPerUpd,V);
                yxx1(:,2:end) = yxx1(:,2:end) + [ addY; addXx ];
            end
        end % doUpdate()
        
        
        
        function doExogenize()
            % `S.Ea` and ea1 can go beyond `S.NPerNonl` if there are endogenized
            % anticipated shocks in the future; the data points are only used to update
            % `yxx1` here, and not to evaluate nonlinear equations.
            %
            % `S.Tune` already includes steady-state line, so that the tunes are
            % compatible with the results in `yxx1`.
            [ea1,eu1,addEa,addEu] = ...
                simulate.linear.exogenize(S,S.M,yxx1(:,2:end),S.Ea,S.Eu);
            if isFastUpd
                yxx1(ixUpdN) = yxx1(ixUpdN) ...
                    + Je*[ addEa(eaAnch); addEu(euAnch) ];
            else
                % Incremental simulation of endogenized shocks.
                isDeviation = true;
                [addY,addXx] = simulate.linear.plain(S, ...
                    isDeviation,[ ],addEa,addEu,nPerNonl,[ ]);
                yxx1(:,1+(1:nPerNonl)) = yxx1(:,1+(1:nPerNonl)) ...
                    + [ addY; addXx ];
            end
            e1 = ea1;
            e1(:,1) = e1(:,1) + eu1(:,1);
            e1 = [ zeros(ne,1), e1 ];
        end % doExogenize()
        
        
        
        function doErrors()
            if ~isempty(errMsg)
                utils.error('simulate:selective:segment', ...
                    ['Error evaluating this nonlinear equation: %s\n ', ...
                    '\tUncle says: %s'], ...
                    errMsg{:});
            end
            if any(ixNan)
                utils.error('simulate:selective:segment', ...
                    ['This nonlinear equation produces ', ...
                    'NaN or Inf: %s'], ...
                    S.Eqtn{ixNan});
            end
        end % doErrors()
    end % doEvalDcy()



    function doRptFailure()
        if S.IsError
            % @@@@@ MOSW
            msgFunc = @(varargin) utils.error(varargin{:});
        else
            % @@@@@ MOSW
            msgFunc = @(varargin) utils.warning(varargin{:});
        end
        switch Exit
            case -1
                msgFunc('simulate:selective:segment', ...
                    ['Nonlinear simulation #%g, segment %s, ', ...
                    'reached max number of iterations without convergence.'], ...
                    S.ILoop,strtrim(sgmStr));
            case -2
                msgFunc('simulate:selective:segment', ...
                    ['Nonlinear simulation #%g, segment %s, ', ...
                    'crashed at Inf, -Inf, or NaN.'], ...
                    S.ILoop,strtrim(sgmStr));
        end
    end % doRptFailure()



end
