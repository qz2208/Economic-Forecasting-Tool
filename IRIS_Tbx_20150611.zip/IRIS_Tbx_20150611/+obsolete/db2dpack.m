function varargout = db2dpack(varargin)
[varargout{1:nargout}] = db2dp(varargin{:});
end