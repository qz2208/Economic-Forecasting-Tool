function [gap,tnd] = hpgap(varargin)
[tnd,gap] = hpf(varargin{:});
end