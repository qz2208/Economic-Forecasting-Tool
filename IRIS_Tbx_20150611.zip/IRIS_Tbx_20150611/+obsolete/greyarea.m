function h = greyarea(varargin)
warning('iris:obsolete','GREYAREA is an obsolete function name. Use HIGHLIGHT instead.');
h = highlight(varargin{:});
end