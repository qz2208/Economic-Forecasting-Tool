function x = arfilter(varargin)

warning('iris:obsolete','ARFILTER is an obsolete function name. Use ARF instead.');
x = arf(varargin{:});

end