function reconfig(varargin)

warning('iris:obsolete','RECONFIG is an obsolete function name. Use IRISSET instead.');
irisset(varargin{:});

end