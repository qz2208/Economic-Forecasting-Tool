function h = grayarea(varargin)
warning('iris:obsolete','GRAYAREA is an obsolete function name. Use HIGHLIGHT instead.');
h = highlight(varargin{:});
end